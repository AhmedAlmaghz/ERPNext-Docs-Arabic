\n## مقدمة إلى CRM

يساعدك ERPNext على تتبع الأعمال ** الفرص ** من ** العملاء المحتملين ** و ** العملاء ** ، وإرسال ** عروض الأسعار ** وحجز ** طلبات المبيعات **.

## دروس الفيديو

1. [العميل المحتمل والفرصة والاقتباس] (https://frappe.school/courses/erpnext-sales-crm/learn/1.1)
2. [رسالة إخبارية] (https://docs.erpnext.com/docs/v13/user/videos/learn/newsletter)

التالي: [وحدة البيع] (https://docs.erpnext.com/docs/v13/user/manual/en/selling)