\n**سؤال:**

أرغب في إزالة الوصف من تنسيق الطباعة الخاص بي لأنه يشغل مساحة كبيرة:

! [] (https://docs.erpnext.com/files/cDYxb5o.png)

ولكن عندما أفعل ذلك باستخدام [منشئ تنسيق الطباعة] (https://docs.erpnext.com/docs/user/manual/en/setting-up/print/print-format-builder) ، ينتهي بي الأمر بفقدان العنصر الخاص بي الرمز والاسم كذلك. كيف يمكن اصلاح هذا؟

! [] (https://docs.erpnext.com/files/Fredaow.png)

**إجابة:**

هذا بسبب تمكين خيار ** Compact Item Print ** في إعدادات الطباعة.

! [] (https://docs.erpnext.com/files/lCGM2tO.png)

يمكنك تعطيل هذا الخيار ثم إلغاء تحديد الوصف في منشئ تنسيق الطباعة. هذا يجب أن يحل المشكلة بالنسبة لك.

! [] (https://docs.erpnext.com/files/6MI1aNw.png)