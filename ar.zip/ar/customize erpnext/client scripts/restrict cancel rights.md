\n## تقييد حقوق الإلغاء

أضف معالجًا إلى حدث "custom_before_cancel":

""
cur_frm.cscript.custom_before_cancel = وظيفة (مستند) {
    if (frappe.user_roles.indexOf ("مستخدم الحسابات")! = - 1 && frappe.user_roles.indexOf ("مدير الحسابات") == - 1
            && user_roles.indexOf ("مدير النظام") == - 1) {
        إذا (flt (doc.grand_total)> 10000) {
            frappe.msgprint ("لا يمكنك إلغاء هذه المعاملة ، لأن المجموع الكلي \
                أكبر من 10000 بوصة) ؛
            frappe.validated = خطأ ؛
        }
    }
}
""