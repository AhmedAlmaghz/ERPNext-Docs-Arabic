\n## غرفة الفندق

غرفة الفندق هي غرفة رئيسية لإنشاء غرف فندقية للحجز

! [غرفة الفندق] (https://docs.erpnext.com/files/hotel-room.png)