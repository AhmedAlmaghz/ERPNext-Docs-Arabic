\n## حجوزات المطاعم

بمجرد الانتهاء من إعداد المطعم والطاولات ، يمكنك البدء في إجراء الحجوزات لمطعمك.

لإجراء حجز ، ما عليك سوى إجراء حجز مطعم جديد من صفحة المطعم وتعيين الوقت وعدد الأشخاص واسم الضيف.

! [حجز] (https://docs.erpnext.com/docs/v14/user/manual/en/h Hospitality/٪7B٪7Bdocs_base_url٪7D٪7D/v13/assets/img/restaurant/reservation.png)

### كانبان

أثناء دخول ضيوفك ، يمكنك أيضًا إدارة الحجوزات عن طريق إنشاء لوحة كانبان بسيطة لنفسها.

[حجز مجلس كانبان] (https://docs.erpnext.com/files/reservation-kanban.png)