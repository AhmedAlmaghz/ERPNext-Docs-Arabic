\n## تخصيص ERPNext

يعد ERPNext نظامًا سهل الاستخدام للغاية ، إلا أنه قابل للتخصيص بدرجة كبيرة. اعتمادًا على طبيعة أعمالك وعمليات عملك ، يمكنك اختيار إضافة حقول وتقارير وتنسيقات طباعة جديدة أو تخصيصها ، ونوع المستند (DocType) والمزيد.

## دروس الفيديو

1. [تخصيص الحقل] (https://docs.erpnext.com/docs/v13/user/videos/learn/field-customization.html)
2. [مُنشئ التقارير] (https://docs.erpnext.com/docs/v13/user/videos/learn/report-builder.html)
3. [Workflow] (https://docs.erpnext.com/docs/v13/user/videos/learn/workflow.html)
4. [بيانات التحديث المجمع] (https://docs.erpnext.com/docs/v13/user/videos/learn/bulk-update.html)