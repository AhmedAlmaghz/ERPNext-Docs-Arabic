\n## مشاكل

تسهل بوابة العملاء على العميل إثارة مخاوفه. تسهل الواجهة البسيطة والبديهية على العميل الإبلاغ عن مخاوفه على أنها مشكلات. يمكنهم عرض الموضوع الكامل لمحادثاتهم.

#### قائمة المشكلات الفارغة

! [قائمة المشكلات] (https://docs.erpnext.com/files/portal-ticket-list-empty.png)

#### مشكلة جديدة

! [إصدار جديد] (https://docs.erpnext.com/files/portal-new-ticket.png)

#### العدد المفتوح

! [تم طرح المشكلة] (https://docs.erpnext.com/files/portal-ticket-1.gif)

#### الرد على المشكلة

! [رد على المشكلة] (https://docs.erpnext.com/files/portal-ticket-reply.gif)