\n## تخريد أحد الأصول

** عندما يصبح أحد الأصول غير صالح للاستخدام ، يتم إلغاؤه. **

يمكنك إلغاء الأصل في أي وقت باستخدام الزر "Scrap Asset" في سجل الأصول. سيُطلب منك التأكيد ، انقر فوق "نعم" وسيتم إلغاء الأصل.

! [الأصل ملغى] (https://docs.erpnext.com/files/asset-scrapped.png)

يتم الخصم من حساب "حساب الربح / الخسارة عند التخلص من الأصول" المذكور في الشركة بالقيمة الحالية (بعد الاستهلاك) للأصل.

سيتم إنشاء إدخال دفتر اليومية إذا قمت بإلغاء أحد الأصول:

! [الأصل] (https://docs.erpnext.com/files/scrap-journal-entry.png)

بعد الإلغاء ، يمكنك أيضًا استعادة الأصل باستخدام زر "استعادة الأصل" من مدير الأصول.

1. [صيانة الأصول] (https://docs.erpnext.com/docs/v13/user/manual/en/asset/asset-maintenance)
2. [تعديل قيمة الأصول] (https://docs.erpnext.com/docs/v13/user/manual/en/asset/asset-value-adjustment)
3. [إهلاك الأصول] (https://docs.erpnext.com/docs/v13/user/manual/en/asset/asset-depreciation)