\n## مشاركة التقارير

هناك نوعان من التقارير في ERPNext للمشاركة. حصة الرصيد ودفتر الأستاذ.

هذا عرض تقرير يعطي قائمة بجميع الأسهم التي يمتلكها مساهم معين وقيمتها.

للوصول إلى تقرير Share Balance ، انتقل إلى:

> الصفحة الرئيسية> المحاسبة> إدارة الأسهم> رصيد الأسهم

! [تقرير رصيد المشاركة] (https://docs.erpnext.com/files/share-balance-report.png)

هذا عرض تقرير يعطي قائمة بجميع المعاملات التي قام بها مساهم معين.

للوصول إلى تقرير Share Ledger ، انتقل إلى:

> الصفحة الرئيسية> المحاسبة> إدارة الأسهم> Share Ledger

! [مشاركة تقرير دفتر الأستاذ] (https://docs.erpnext.com/files/share-ledger-report.png)

1. [المساهم] (https://docs.erpnext.com/docs/v13/user/manual/en/accounts/shareholder)
2. [نقل المشاركة] (https://docs.erpnext.com/docs/v13/user/manual/en/accounts/share-transfer)