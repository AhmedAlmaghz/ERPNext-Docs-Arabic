\n## طباعة الفاتورة الملغاة

كيفية طباعة الفاتورة الملغاة؟

في ** إعدادات الطباعة ** ، يوجد مربع اختيار يسمح بطباعة الفواتير الملغاة.

! [] (https://docs.erpnext.com/files/Kf9D1Q2.png)

أعد تحميل ERPNext للإعدادات لتعكس:

! [] (https://docs.erpnext.com/files/qFVSpRT.png)