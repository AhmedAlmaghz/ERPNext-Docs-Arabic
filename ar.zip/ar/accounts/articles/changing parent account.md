\n## تغيير حساب الوالدين

! [تغيير حساب الوالد] (https://docs.erpnext.com/files/change-parent-account.gif)

قام المسؤول بتحريره منذ عام واحد · * [1 مراجعات] (https://docs.erpnext.com/docs/v14/user/manual/en/accounts/articles/changing-parent-account/revisions)
* [تحرير الصفحة] (https://docs.erpnext.com/docs/v14/user/manual/en/accounts/articles/changing-parent-account/edit-wiki)
* حذف الصفحة
* [صفحة جديدة] (https://docs.erpnext.com/docs/v14/user/manual/en/accounts/articles/changing-parent-account/new-wiki)

[← دمج الحسابات] (https://docs.erpnext.com/docs/v14/user/manual/en/accounts/articles/merging-accounts) [إنشاء السنة المالية ←] (https://docs.erpnext.com / docs / v14 / user / manual / en / accounts / articles / إنشاء السنة المالية)