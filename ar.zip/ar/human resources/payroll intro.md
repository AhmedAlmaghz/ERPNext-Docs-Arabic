\nتعد معالجة كشوف المرتبات وظيفة مهمة لكل موارد بشرية في المؤسسة. تبسط Frappe HR هذه العملية إلى حد كبير من خلال تقديم مجموعة من الميزات التي يمكنك الاستفادة منها من إدارة هيكل الرواتب إلى معالجة كشوف رواتب الموظفين بالجملة. اقرأ الوثائق التالية لفهم كيفية تكوين واستخدام Frappe HR الموارد البشرية لتعزيز معالجة كشوف المرتبات الخاصة بك.

1. [فترة الرواتب] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/payroll-period)
2. [مكون الراتب] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/salary-component)
3. [هيكل الرواتب] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/salary-structure)
4. [تعيين هيكل الراتب] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/salary-structure-assignment)
5. [إدخال كشوف المرتبات] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/payroll-entry)
6. [الراتب الإضافي] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/additional-salary)
7. [مكافأة الاحتفاظ] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/retention-bonus)
8. [حوافز الموظفين] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/employee-incentive)