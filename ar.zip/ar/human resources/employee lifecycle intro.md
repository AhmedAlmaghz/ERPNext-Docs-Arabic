\nتتعلق إدارة دورة حياة الموظف بالمراحل المختلفة التي يمر بها الموظف أثناء التوظيف في إحدى المنظمات. من المهم لأقسام الموارد البشرية في معظم الشركات الاحتفاظ بسجلات لهذه التغييرات التي يمر بها الموظفون في جميع أنحاء الشركة. يبسط Frappe HR أنشطة الموارد البشرية هذه ، اقرأ الأقسام التالية لفهم كيفية القيام بذلك.

## 1 \. المواضيع

1. [الموظف على متن الطائرة] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/employee-onboarding)
2. [ترقية الموظف] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/employee_promotion)
3. [فصل الموظف] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/employee-separation)
4. [نقل موظف] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/employee_transfer)
5. [خريطة مهارات الموظف] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/employee_skill_map)