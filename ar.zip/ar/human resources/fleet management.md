\nيساعد قسم إدارة الأسطول في الموارد البشرية مؤسستك على إدارة أسطول مركباتها وتتبع نفقاتها.

لاستخدام إدارة الأسطول في Frappe HR ، يمكنك القيام بما يلي:

1. إعداد السيارة.
2. أدخل سجلات السيارة بانتظام.
3. تقديم مطالبات المصاريف لمصاريف السيارة.
4. عرض تقارير مصاريف السيارة.

1. [مركبة] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/vehicle)
2. [سجل السيارة] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/vehicle-log)