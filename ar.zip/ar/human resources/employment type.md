\n** يمكنك توظيف أشخاص تحت عدد من الفئات لكل منها أجرها الخاص واستحقاقات الإجازة. هذا يسمى نوع التوظيف. **

يسمح لك Frappe HR بتحديد نوع التوظيف من قائمة محددة مسبقًا أو حتى إنشاء نوع توظيف جديد بناءً على متطلباتك.

للوصول إلى نوع التوظيف ، انتقل إلى:

> الصفحة الرئيسية> الموارد البشرية> الموظف> نوع التوظيف

## 1 \. كيفية إنشاء نوع التوظيف

1. اذهب إلى قائمة نوع التوظيف ، وانقر على جديد.
    
2. أدخل اسم نوع التوظيف.
    
3. حفظ.
    
    ! [نوع التوظيف] (https://docs.erpnext.com/files/employment-type.png)
    

يمكن ربط نوع التوظيف بالسيد [الموظف] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/employee).

1. [موظف] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/employee)
    
2. [نوع التوظيف] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/employment-type)
    
3. [الفرع] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/branch)
    
4. [القسم] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/department)
    
5. [التعيين] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/designation)
    
6. [درجة الموظف] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/employee-grade)