\nسيساعدك هذا القسم على فهم كيف يمكّنك Frappe HR من إدارة جدول الإجازات لمؤسستك بكفاءة. كما يشرح كيف يمكن للموظفين التقدم للحصول على الإجازات.

يتم التحكم في عدد ونوع الإجازات التي يمكن للموظف التقدم بها من خلال تخصيص الإجازات. يمكنك إنشاء تخصيص إجازة لفترة إجازة بناءً على سياسة الإجازة الخاصة بالشركة. يمكنك أيضًا تخصيص إجازات إضافية لموظفيك وإنشاء تقارير لتتبع الإجازات التي يأخذها الموظفون.

يمكن للموظفين أيضًا إنشاء طلبات إجازة ، والتي يمكن لمديريهم (المعتمدين على الإجازة) الموافقة عليها أو رفضها. يمكن للموظف اختيار الإجازات من عدد من أنواع الإجازات مثل الإجازة المرضية والإجازة العرضية وإجازة الامتياز وما إلى ذلك.

1. [قائمة العطلات] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/holiday-list)
    
2. [نوع الإجازة] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/leave-type)
    
3. [فترة الإجازة] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/leave-period)
    
4. [سياسة الإجازة] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/leave-policy)
    
5. [ترك التخصيص] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/leave-allocation)
    
6. [اترك التطبيق] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/leave-application)
    
7. [طلب إجازة تعويضية] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/compensatory-leave-request)
    
8. [إيداع الأموال] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/leave-encashment)
    
9. [قائمة الحظر مغادرة] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/leave-block-list)