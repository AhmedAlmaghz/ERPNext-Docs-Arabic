\n## إدارة التحول

تساعدك وحدة إدارة التحول في Frappe HR HR على إدارة المناوبات بكفاءة لموظفيك.

باستخدام هذه الوحدة ، يمكنك:

1. [إعداد نوع التحول] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/shift_type).
    
2. [إنشاء طلبات التحول] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/shift_request).
    
3. [عرض وإدارة مهام التحول] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/shift_assignment).
    
4. [إعداد حقل معرف جهاز الحضور في الموظف الرئيسي] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/auto-attendance#3-setup-attendance-device-id -الحقل في الموظف).
    
5. [إنشاء تسجيلات وصول الموظف] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/employee_checkin).
    
6. [يقوم النظام بعد ذلك بمعالجة الحضور التلقائي إذا تم تمكينه] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/auto-attendance).