\n** الدخل الآخر للموظف هو مستند للإعلان عن الدخل الآخر للموظف من مصادر مختلفة. **

الدخل الآخر للموظف مهم أيضًا لحساب التزام ضريبة الدخل للموظف. في Frappe HR ، يمكن للموظف الإعلان عن دخله الآخر باستخدام هذا المستند.

للوصول إلى دخل الموظف الآخر ، انتقل إلى:> الصفحة الرئيسية> الموارد البشرية> ضريبة الموظفين والمزايا> دخل الموظف الآخر

## 1 \. كيفية إنشاء دخل آخر للموظف

1. اذهب إلى: دخل الموظف الآخر> جديد.
2. حدد الموظف والشركة.
3. حدد فترة الرواتب.
4. أدخل المبلغ ومصدره.
5. حفظ وإرسال.

! [دخل الموظف الآخر] (https://docs.erpnext.com/files/employee-other-income.png)

1. [هيكل الرواتب] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/salary-structure)
2. [هيكل الرواتب] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/salary-slip)
3. [إدخال كشوف المرتبات] (https://docs.erpnext.com/docs/v14/user/manual/en/human-resources/payroll-entry)