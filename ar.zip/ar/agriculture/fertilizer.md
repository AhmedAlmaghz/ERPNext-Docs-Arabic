\n## سماد

يستخدم هذا لتتبع الأسمدة المتاحة وتكوينها الكيميائي المرتبط بمدير السلعة

! [مهمة] (https://docs.erpnext.com/files/fertilizer.png)