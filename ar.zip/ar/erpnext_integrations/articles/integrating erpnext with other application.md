\nفي الوقت الحالي ، يحتوي ERPNext على تكامل خارج الصندوق متاح لبعض التطبيقات مثل Shopify وبوابة الرسائل القصيرة وبوابة الدفع. لدمج ERPNext مع تطبيق آخر ، يمكنك استخدام REST API لـ Frappe. تحقق من الروابط التالية لمعرفة المزيد حول REST API of Frappe.

[Frappe Rest API] (https://frappeframework.com/docs/user/en/guides/integration/rest_api)