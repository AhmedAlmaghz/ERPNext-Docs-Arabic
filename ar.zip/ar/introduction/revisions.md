\n## المراجعات: مقدمة

* [رابط معطل ثابت. مقدمة معدلة] (https://docs.erpnext.com/compare؟wiki_page=493337778a&&compare=b1984a4052)
    
    palkan تم تحريره منذ 10 أشهر
    

* [تنسيق المقدمة المعدلة] (https://docs.erpnext.com/compare؟wiki_page=493337778a&&compare=486c173e75)
    
    محمد تم تحريره منذ سنة
    

* [مقدمة معدلة] (https://docs.erpnext.com/compare؟wiki_page=493337778a&&compare=9c011c0602)
    
    قام المسؤول بتحريره منذ سنة واحدة
    

* [] (https://docs.erpnext.com/compare؟wiki_page=493337778a&&compare=93397512c8)
    
    قام المسؤول بتحريره منذ سنة واحدة
    

* [إنشاء صفحة Wiki] (https://docs.erpnext.com/compare؟wiki_page=493337778a&&compare=53e3daa732)
    
    تم تحرير المسؤول منذ 1 سنوات