\n## بوابة العملاء

تم تصميم بوابة العملاء لتوفير إمكانية الوصول السهل لعملاء الشركة.

تتيح هذه البوابة للعملاء تسجيل الدخول ومعرفة المعلومات ذات الصلة بهم. يمكن للعملاء تتبع تاريخ الاتصال لرسائل البريد الخاصة بهم. يمكنهم أيضًا التحقق من حالة الطلب عن طريق تسجيل الدخول إلى موقع الويب.

### المواضيع

1. [فواتير طلبات العميل وحالة الشحن] (https://docs.erpnext.com/docs/v13/user/manual/en/customer-portal/customer-orders-invoices-and-shipping-status)
2. [تسجيل الدخول إلى البوابة] (https://docs.erpnext.com/docs/v13/user/manual/en/customer-portal/portal-login)
3. [الاشتراك] (https://docs.erpnext.com/docs/v13/user/manual/en/customer-portal/sign-up)
4. [الإصدارات] (https://docs.erpnext.com/docs/v13/user/manual/en/customer-portal/issues)