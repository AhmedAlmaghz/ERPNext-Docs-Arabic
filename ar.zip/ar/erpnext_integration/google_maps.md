\n## تكامل خرائط جوجل

يوفر ERPNext تكاملاً مع خرائط Google لحساب وقت رحلات التسليم وتحسينه.

## كيفية إعداد خرائط جوجل التكامل

لإعداد خرائط Google للسماح لـ ERPNext بحساب وقت رحلة التسليم وتحسينه ، اتبع الخطوات:

* تمكين الوصول إلى واجهة برمجة التطبيقات [إعدادات Google] (https://docs.erpnext.com/docs/v13/user/manual/en/erpnext_integration/google_settings#for-google-maps).

## كيفية استخدام خرائط جوجل التكامل

### حساب رحلات التوصيل وتحسينها

* بمجرد نجاح تكامل خرائط Google ، يمكنك حساب الوقت المقدر للوصول لوقف التسليم أو تحسين توقف التسليم! [] (https://docs.erpnext.com/files/google_maps.gif)