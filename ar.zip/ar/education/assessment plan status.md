\n## حالة خطة التقييم

[docs / v13 / user / manual / en / education] (https://docs.erpnext.com/docs/v14/user/manual/en/education/docs/v13/user/manual/en/education)