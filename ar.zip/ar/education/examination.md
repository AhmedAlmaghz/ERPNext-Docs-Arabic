\n## فحص

يمكن استخدام سجل الامتحان لتتبع جدول الامتحان ونتائج ذلك الامتحان.

! [الفحص] (https://docs.erpnext.com/files/examination.png)