\n## نتيجة التقييم

** نتيجة التقييم هي سجل للعلامات / الدرجات التي حصل عليها الطالب لتقييم معين. **

يتم إنشاء نتيجة التقييم في الواجهة الخلفية بناءً على العلامات التي تم إدخالها في [أداة نتيجة التقييم] (https://docs.erpnext.com/docs/v13/user/manual/en/education/assessment_result_tool).

! [نتيجة التقييم] (https://docs.erpnext.com/docs/v14/user/manual/en/education/٪7B٪7Bdocs_base_url٪7D٪7D/img/education/assessment/assessment-result.png)

#### فيديو تعليمي عن نتيجة التقييم